﻿using ProjectQ;
using System.Text.Json;

List<Car> car= new()
{
    new Car
    {
        Model = "Audi",
        Bouwjaar = 2022,
        Bestuurdernaam = new Driver
        {
            Naam = "Bestuurder1",
            Leeftijd = 20,
            Rijbewijsnummer = "12516520"
        }
    },
    new Car
    {
        Model = "BMW",
        Bouwjaar = 2020,
        Bestuurdernaam = new Driver
        {
            Naam = "Bestuurder2",
            Leeftijd = 24,
            Rijbewijsnummer = "48710231"
        }
    },
    new Car
    {
        Model = "Mercedes",
        Passagiers = new List<Human>
        {
            new Human {Naam = "Passagier1", Leeftijd = 38},
            new Human {Naam = "Passagier2", Leeftijd = 29},
            new Human {Naam = "Passagier3", Leeftijd = 48},
        }
    }
};

var jsonString = JsonSerializer.Serialize(car);
File.WriteAllText("cars.json", jsonString);
Console.WriteLine("Gegevens zijn opgeslagen in cars.json");
