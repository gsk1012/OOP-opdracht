﻿namespace ProjectQ
{
    public class Car
    {
        public string? Model { get; set; }
        public int? Bouwjaar { get; set; }
        public Driver? Bestuurdernaam { get; set; }
        public List<Human>? Passagiers { get; set; }
    }
}
