﻿namespace ProjectQ
{
    public class Driver : Human
    {
        public string? Rijbewijsnummer { get; set; }
    }
}
