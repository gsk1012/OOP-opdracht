﻿namespace ProjectQ
{
    public class Human
    {
        public string? Naam { get; set; }
        public int Leeftijd { get; set; }

    }
}